

import { useQueryClient, useQuery } from "@tanstack/react-query";
import { User } from "../types/types";
import {
  FRAMER_TOKEN_KEY,
  decodeJWTPayload,
  loadStoredFramerToken,
  setInMemorySessionToken,
  clearInMemorySessionToken,
  getValidSessionToken,
  makeAuthenticatedRequest,
  requestOTP,
  verifyOTPNetwork,
  registerSite,
  publishSettings,
  getPublishedSettings,
  connectCustomDomain,
  registerAccessibilityScript,
  applyAccessibilityScript,
} from '../api/framer';

// ─── Auth state type ──────────────────────────────────────────────────────────

interface AuthState {
  user: User;
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

const dispatchAuthSuccess = (detail: any) => {
  window.dispatchEvent(new CustomEvent('accessbit-auth-success', { detail }));
};

export function useAuth() {
  const queryClient = useQueryClient();

  // Reads user data directly from the JWT payload — no separate localStorage entry.
  const { data: authState, isLoading: isAuthLoading } = useQuery<AuthState>({
    queryKey: ["auth"],
    queryFn: async () => {
      if (localStorage.getItem("explicitly_logged_out")) {
        return { user: { firstName: "", email: "" } };
      }
      const token = loadStoredFramerToken();
      if (!token) return { user: { firstName: "", email: "" } };
      const payload = decodeJWTPayload(token);
      if (!payload) return { user: { firstName: "", email: "" } };
      return {
        user: {
          firstName: payload.firstName || "",
          email: payload.email || "",
          siteId: payload.siteId || "",
        },
      };
    },
    staleTime: Infinity,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    gcTime: 1000 * 60 * 60,
  });

  // ── Logout ──────────────────────────────────────────────────────────────────

  const logout = () => {
    localStorage.setItem("explicitly_logged_out", "true");
    localStorage.removeItem(FRAMER_TOKEN_KEY);
    clearInMemorySessionToken();
    queryClient.setQueryData(["auth"], { user: { firstName: "", email: "" } });
    queryClient.clear();
  };

  // ── Auth success handler (updates React state after network call) ─────────────

  const processAuthSuccessFromData = (token: string, user: User) => {
    try {
      setInMemorySessionToken(token);
      localStorage.setItem(FRAMER_TOKEN_KEY, token);
      localStorage.removeItem("explicitly_logged_out");

      queryClient.clear();
      queryClient.setQueryData<AuthState>(["auth"], { user });

      dispatchAuthSuccess(user);
    } catch {
      // ignore
    }
  };

  // ── OTP auth ────────────────────────────────────────────────────────────────

  const verifyOTP = async (email: string, otp: string): Promise<void> => {
    const { token, user } = await verifyOTPNetwork(email, otp);
    processAuthSuccessFromData(token, user);
    // Register the site in a separate post-auth call — never bundled with OTP verify.
    // Returns a new JWT with siteId embedded; store it so silent auth works on next open.
    // Failure here does not block the user; they are already authenticated.
    try {
      const result = await registerSite();
      if (result?.siteId && result?.token) {
        // registerSite() already stored the new token in localStorage + memory.
        // Update React Query state to reflect the siteId.
        queryClient.setQueryData<AuthState>(["auth"], (prev) => ({
          user: {
            firstName: prev?.user?.firstName || "",
            email: prev?.user?.email || "",
            siteId: result.siteId,
          },
        }));
      }
    } catch {
      // Non-blocking — site will be registered on next OTP verify if this fails
    }
  };

  // ── Silent auth (restore from JWT on startup, no server call) ───────────────

  const attemptSilentAuth = async (): Promise<boolean> => {
    try {
      if (localStorage.getItem("explicitly_logged_out")) return false;
      const token = loadStoredFramerToken();
      if (!token) return false;

      setInMemorySessionToken(token);
      const payload = decodeJWTPayload(token);

      queryClient.setQueryData<AuthState>(["auth"], {
        user: {
          firstName: payload?.firstName || "",
          email: payload?.email || "",
          siteId: payload?.siteId || "",
        },
      });

      return true;
    } catch {
      return false;
    }
  };

  const attemptAutoRefresh = async (): Promise<boolean> => {
    try {
      if (localStorage.getItem("explicitly_logged_out")) return false;
      return await attemptSilentAuth();
    } catch {
      return false;
    }
  };

  const getSessionToken = async () => getValidSessionToken();

  return {
    user: authState?.user || { firstName: "", email: "" },
    isAuthLoading,
    logout,
    requestOTP,
    verifyOTP,
    makeAuthenticatedRequest,
    publishSettings,
    connectCustomDomain,
    getPublishedSettings,
    registerAccessibilityScript,
    applyAccessibilityScript,
    attemptAutoRefresh,
    getSessionToken,
  };
}
